#ifndef NODE_H
#define NODE_H

struct Node {
    char symbol;
    int frequency;
    Node* left;
    Node* right;

    Node(char s, int f) : symbol(s), frequency(f), left(nullptr), right(nullptr) {}
};

#endif

