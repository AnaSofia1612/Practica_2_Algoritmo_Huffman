
#include <iostream>
#include <string>
#include "Huffman.h"

using namespace std;

int main() {
    string text;
    cout << "Ingrese un texto (>=30 caracteres):\n";
    getline(cin, text);

    if (text.size() < 30) {
        cout << "❌ El texto debe tener al menos 30 caracteres.\n";
        return 1;
    }

    Huffman h;

    // Fase 1: Frecuencias y árbol
    h.computeFrequencies(text);
    h.printFrequencies();
    h.buildTree();
    h.printNodeTable();
    h.buildCodes();
    h.printCodeLengths();
    h.printHuffCodes();

    // Fase 2: Códigos canónicos
    h.buildCanonicalCodes();
    h.printCanonicalCodes();

    // Fase 3: Compresión
    string compressed = h.compress(text);
    cout << "\nTexto comprimido (primeros 128 bits): "
         << compressed.substr(0, 128) << "...\n";
    cout << "Texto comprimido (hex, primeros 32 digitos): "
         << h.toHexString(compressed).substr(0, 32) << "...\n";

    int originalSize = h.getOriginalSize(text);
    int compressedSize = h.getCompressedSize(text);
    cout << "Size original: " << originalSize << " bits\n";
    cout << "Size comprimido: " << compressedSize << " bits\n";
    cout << "Ratio: " << (double)compressedSize / originalSize
         << " | Reduccion: " << (100.0 * (1 - (double)compressedSize / originalSize)) << "%\n";

    return 0;
}



