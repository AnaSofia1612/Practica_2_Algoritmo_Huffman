
#include "Huffman.h"

// ========================
// Fase 1: Huffman normal
// ========================

void Huffman::computeFrequencies(const string& text) {
    freq.clear();
    for (char c : text) {
        freq[c]++;
    }
}

void Huffman::printFrequencies() {
    cout << "\n--- Frecuencias ---\n";
    for (auto& p : freq) {
        cout << "'" << p.first << "' : " << p.second << "\n";
    }
}

void Huffman::buildTree() {
    priority_queue<Node*, vector<Node*>, Compare> pq;
    for (auto& p : freq) {
        pq.push(new Node(p.first, p.second));
    }

    while (pq.size() > 1) {
        Node* left = pq.top(); pq.pop();
        Node* right = pq.top(); pq.pop();

        Node* merged = new Node('\0', left->frequency + right->frequency);
        merged->left = left;
        merged->right = right;
        pq.push(merged);
    }

    root = pq.top();
}

void Huffman::generateCodes(Node* node, string code) {
    if (!node) return;

    if (node->symbol != '\0') {
        huffCodes[node->symbol] = code;
    }

    generateCodes(node->left, code + "0");
    generateCodes(node->right, code + "1");
}

void Huffman::buildCodes() {
    huffCodes.clear();
    if (!root) return;

    if (!root->left && !root->right) {
        // Caso especial: solo un símbolo
        huffCodes[root->symbol] = "0";
    } else {
        generateCodes(root, "");
    }
}

void Huffman::printHuffCodes() {
    cout << "\n--- Huffman Codes (no canonicos) ---\n";
    for (auto& p : huffCodes) {
        cout << "'" << p.first << "' : " << p.second << "\n";
    }
}

void Huffman::printCodeLengths() {
    cout << "\n--- Longitudes de Codigos ---\n";
    for (auto& p : huffCodes) {
        cout << "'" << p.first << "' : " << p.second.size() << " bits\n";
    }
}

// ========================
// Tabla de nodos del árbol
// ========================
#include <iomanip>

void Huffman::printNodeTable() {
    if (!root) return;

    cout << "\n--- Tabla de nodos (arbol Huffman) ---\n";
    cout << left << setw(5) << "ID"
         << setw(10) << "Simbolo"
         << setw(12) << "Frecuencia"
         << setw(8) << "ID_Izq"
         << setw(8) << "ID_Der" << "\n";

    map<Node*, int> ids;
    int counter = 0;

    queue<Node*> q;
    q.push(root);
    ids[root] = counter++;

    while (!q.empty()) {
        Node* node = q.front(); q.pop();

        int id = ids[node];
        cout << left << setw(5) << id;

        string sym;
        if (node->symbol != '\0')
            sym = "'" + string(1, node->symbol) + "'";
        else
            sym = "*";

        cout << setw(10) << sym
             << setw(12) << node->frequency;

        if (node->left) {
            ids[node->left] = counter++;
            cout << setw(8) << ids[node->left];
            q.push(node->left);
        } else {
            cout << setw(8) << -1;
        }

        if (node->right) {
            ids[node->right] = counter++;
            cout << setw(8) << ids[node->right];
            q.push(node->right);
        } else {
            cout << setw(8) << -1;
        }

        cout << "\n";
    }
}

// ========================
// Fase 2: Huffman canónico
// ========================

void Huffman::buildCanonicalCodes() {
    vector<pair<char, int>> lengths;
    for (auto& p : huffCodes) {
        lengths.push_back({p.first, (int)p.second.size()});
    }

    sort(lengths.begin(), lengths.end(), [](auto& a, auto& b) {
        if (a.second == b.second) return a.first < b.first;
        return a.second < b.second;
    });

    canonicalCodes.clear();
    unsigned int code = 0;
    int prevLen = 0;

    for (auto& p : lengths) {
        char symbol = p.first;
        int len = p.second;

        code <<= (len - prevLen);

        string codeStr = "";
        for (int i = len - 1; i >= 0; i--) {
            codeStr.push_back(((code >> i) & 1) ? '1' : '0');
        }

        canonicalCodes[symbol] = codeStr;
        code++;
        prevLen = len;
    }
}

void Huffman::printCanonicalCodes() {
    cout << "\n--- Huffman Codes (canonicos) ---\n";
    for (auto& p : canonicalCodes) {
        cout << "'" << p.first << "' : " << p.second << "\n";
    }
}

// ========================
// Fase 3: Compresión
// ========================

string Huffman::compress(const string& text) {
    string encoded = "";
    for (char c : text) {
        encoded += canonicalCodes[c];
    }
    return encoded;
}

int Huffman::getOriginalSize(const string& text) {
    return text.size() * 8;
}

int Huffman::getCompressedSize(const string& text) {
    int total = 0;
    for (char c : text) {
        total += canonicalCodes[c].size();
    }
    return total;
}

string Huffman::toHexString(const string& bits) {
    string hex = "";
    for (size_t i = 0; i < bits.size(); i += 4) {
        int val = 0;
        for (size_t j = 0; j < 4 && i + j < bits.size(); j++) {
            val = (val << 1) + (bits[i + j] - '0');
        }
        char h = (val < 10) ? ('0' + val) : ('A' + (val - 10));
        hex.push_back(h);
    }
    return hex;
}
