#ifndef COMPARE_H
#define COMPARE_H

#include "Node.h"

// Comparador para priority_queue (min-heap)
struct Compare {
    bool operator()(Node* a, Node* b) {
        if (a->frequency == b->frequency) {
            return a->symbol > b->symbol; // desempate por carácter (orden alfabético)
        }
        return a->frequency > b->frequency; // menor frecuencia tiene prioridad
    }
};

#endif

