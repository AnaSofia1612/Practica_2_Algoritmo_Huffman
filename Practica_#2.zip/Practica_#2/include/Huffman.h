#ifndef HUFFMAN_H
#define HUFFMAN_H

#include <iostream>
#include <unordered_map>
#include <queue>
#include <string>
#include <vector>
#include <algorithm>
#include <map>
#include "Node.h"
#include "Compare.h"

using namespace std;

class Huffman {
private:
    Node* root; // raíz del árbol Huffman
    unordered_map<char, int> freq; // frecuencias
    unordered_map<char, string> huffCodes; // códigos Huffman normales
    unordered_map<char, string> canonicalCodes; // códigos Huffman canónicos

public:
    Huffman() : root(nullptr) {}

    // Fase 1: Huffman normal
    void computeFrequencies(const string& text);
    void buildTree();
    void buildCodes();
    void generateCodes(Node* node, string code);
    void printFrequencies();
    void printHuffCodes();
    void printCodeLengths();
    void printNodeTable();

    // Getter para la raíz
    Node* getRoot() { return root; }

    // Fase 2: Huffman canónico
    void buildCanonicalCodes();
    void printCanonicalCodes();

    // Fase 3: Compresión
    string compress(const string& text);
    int getOriginalSize(const string& text);
    int getCompressedSize(const string& text);
    string toHexString(const string& bits);
};

#endif






